#include <stdio.h>
#include <hello.h>

void myPrintHello(void) {

  printf("Hello World!\n");

  return;
}
