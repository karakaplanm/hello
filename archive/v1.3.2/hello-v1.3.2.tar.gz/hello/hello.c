#include <hello.h>

int main() {
  myPrintHello();

  return(0);
}

